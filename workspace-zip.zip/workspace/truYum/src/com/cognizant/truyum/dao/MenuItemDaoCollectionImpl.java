package com.cognizant.truyum.dao;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.cognizant.truyum.model.MenuItem;
import com.cognizant.truyum.util.DateUtil;

public class MenuItemDaoCollectionImpl implements MenuItemDao{
    private static List<MenuItem> menuItemList;
    
	public MenuItemDaoCollectionImpl() throws ParseException {
		if(menuItemList==null){
			menuItemList=new ArrayList<MenuItem>();
			menuItemList.add((new MenuItem(1,"Sandwich",99.00f,true,DateUtil.convertToDate("15/03/2017"),"Main Course",true)));
			menuItemList.add((new MenuItem(2,"Burger",129.00f,true,DateUtil.convertToDate("23/12/2017"),"Main Course",false)));
			menuItemList.add((new MenuItem(3,"Pizza",149.00f,true,DateUtil.convertToDate("21/08/2018"),"Main Course",false)));
			menuItemList.add((new MenuItem(4,"French Fries",57.00f,false,DateUtil.convertToDate("02/07/2017"),"Starters",true)));
			menuItemList.add((new MenuItem(5,"Chocolate Brownie",32.00f,true,DateUtil.convertToDate("02/11/2022"),"Dessert",true)));
		}
	}

	public static List<MenuItem> getMenuItemList() {
		return menuItemList;
	}

	public static void setMenuItemList(List<MenuItem> menuItemList) {
		MenuItemDaoCollectionImpl.menuItemList = menuItemList;
	}

	@Override
	public List<MenuItem> getMenuListAdmin() {
		// TODO Auto-generated method stub
		return menuItemList;
	}

	@Override
	public List<MenuItem> getMenuListCustomer() {
		List<MenuItem> res=new ArrayList<>();
		//SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");  
	    Date date = new Date();  
	    for(MenuItem m:menuItemList){
	    	if(m.getDateOfLaunch().before(date)){
	    		res.add(m);
	    	}
	    }
		return res;
	}

	@Override
	public void modifyMenuItem(MenuItem menuItem) {
		for(MenuItem mitem:menuItemList){
			if(mitem.getId()==menuItem.getId()){
				mitem.setName(menuItem.getName());
				mitem.setPrice(menuItem.getPrice());
				mitem.setCategory(menuItem.getCategory());
				mitem.setActive(menuItem.isActive());
				mitem.setDateOfLaunch(menuItem.getDateOfLaunch());
				mitem.setFreeDelivery(menuItem.isFreeDelivery());
			}
		}
	}

	@Override
	public MenuItem getMenuItem(long menuItemId) {
		MenuItem fr=null;
		for(MenuItem m:menuItemList){
			if(m.getId()==menuItemId){
				fr=m;
			}
		}
		return fr;
	}

}
