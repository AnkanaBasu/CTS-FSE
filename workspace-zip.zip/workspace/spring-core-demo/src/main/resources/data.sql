INSERT INTO employees(123,'Ankana',15600.50,'FSE');
INSERT INTO employees(123,'Ankeeta',12000.00,'Advance Java');
INSERT INTO employees(123,'Amit',11200.50,'Java');
INSERT INTO employees(123,'Ashutosh',9200.00,'sellenium');