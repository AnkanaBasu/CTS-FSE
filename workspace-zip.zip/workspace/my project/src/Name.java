import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Name {
 public static void main(String[] args) {
	 Date date6=null;
	 SimpleDateFormat formatter6=new SimpleDateFormat("dd/mm/yyyy HH:mm");  
	 String date="20/09/2019 23:55";
	 try {
		date6=formatter6.parse(date);
	} catch (ParseException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} 
     System.out.println(date6);
 
 
 
 }
}