package com.model;

public class Package {
private String id;
private String sourcePlace;
private String destinationPlace;
private double basicFare;
private int noOfDays;
private double cost;
public Package(String id, String sourcePlace, String destinationPlace, double basicFare, int noOfDays) {
	super();
	this.id = id;
	this.sourcePlace = sourcePlace;
	this.destinationPlace = destinationPlace;
	this.basicFare = basicFare;
	this.noOfDays = noOfDays;
}
public String getId() {
	return id;
}
public void setId(String id) {
	this.id = id;
}
public String getSourcePlace() {
	return sourcePlace;
}
public void setSourcePlace(String sourcePlace) {
	this.sourcePlace = sourcePlace;
}
public String getDestinationPlace() {
	return destinationPlace;
}
public void setDestinationPlace(String destinationPlace) {
	this.destinationPlace = destinationPlace;
}
public double getBasicFare() {
	return basicFare;
}
public void setBasicFare(double basicFare) {
	this.basicFare = basicFare;
}
public int getNoOfDays() {
	return noOfDays;
}
public void setNoOfDays(int noOfDays) {
	this.noOfDays = noOfDays;
}
public double getCost() {
	return cost;
}
public void setCost(double cost) {
	this.cost = cost;
}
@Override
public String toString() {
	return "Package [id=" + id + ", sourcePlace=" + sourcePlace + ", destinationPlace=" + destinationPlace
			+ ", basicFare=" + basicFare + ", noOfDays=" + noOfDays + ", cost=" + cost + "]";
}

@Override
public boolean equals(Object obj) {
	if (this == obj)
		return true;
	if (obj == null)
		return false;
	if (getClass() != obj.getClass())
		return false;
	Package other = (Package) obj;
	if (id == null) {
		if (other.id != null)
			return false;
	} else if (!id.equals(other.id))
		return false;
	return true;
}


}
