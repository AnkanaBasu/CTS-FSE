package practice;

import java.util.Scanner;

public class UserInterface {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 Scanner sc=new Scanner(System.in);
		 Order o=new Order();
			System.out.println("Enter the number of items");
			int num=sc.nextInt();
			System.out.println("Enter the item details");
			for(int i=0;i<num;i++){
				FoodProduct f=new FoodProduct();
				System.out.println("Enter the item id");
				f.setFoodId(sc.nextInt());
				sc.nextLine();
				System.out.println("Enter the item name");
				f.setFoodName(sc.nextLine());
				System.out.println("Enter the cost per unit");
				f.setCostPerUnit(sc.nextDouble());
				sc.nextLine();
				System.out.println("Enter the quantity");
				f.setQuantity(sc.nextInt());
				sc.nextLine();
				o.addToCart(f);
			}
			System.out.println("Enter the bank name to avail offer");
			o.findDiscount(sc.nextLine());
			double amount=o.calculateTotalBill();
			System.out.println("Calculated Bill Amount: "+amount);
	}

}
