package com.cognizant.truyum.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.cognizant.truyum.model.MenuItem;

public class CartDaoSqlImpl implements CartDao{

	@Override
	public void addCartItem(long userId, long menuItemId) {
		try {
			Connection con=ConnectionHandler.getConnection();
			String qr="Insert into cart values(?,?)";
			PreparedStatement ps=con.prepareStatement(qr);
			ps.setLong(1, userId);
			ps.setLong(2, menuItemId);
			int i=ps.executeUpdate();
			System.out.println(i+" item added");
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public List<MenuItem> getAllCartItems(long UserId) {
		List<MenuItem> lm=new ArrayList<MenuItem>();
		try {
			Connection con=ConnectionHandler.getConnection();
			String qr="select m.* from cart c,menuitem m where m.id=c.menuId and c.userId=?";
			PreparedStatement ps=con.prepareStatement(qr);
			ps.setLong(1, UserId);
			ResultSet rs=ps.executeQuery();
			while(rs.next()){
				long id=rs.getLong(1);
				String name=rs.getString(2);
				float price=rs.getFloat(3);
				boolean active=rs.getBoolean(4);
				Date dateOfLaunch=rs.getDate(5);
				String category=rs.getString(6);
				boolean freeDelivery=rs.getBoolean(7);
				MenuItem item=new MenuItem(id, name, price, active, dateOfLaunch, category, freeDelivery);
				lm.add(item);
			}
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return lm;
	}

	@Override
	public void removeCartItem(long userId, long menuItemId) {
		try {
			Connection con=ConnectionHandler.getConnection();
			String qr="Delete from cart where userId=? and menuId=?";
			PreparedStatement ps=con.prepareStatement(qr);
			ps.setLong(1, userId);
			ps.setLong(2, menuItemId);
			int i=ps.executeUpdate();
			System.out.println(i+" item removed");
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("Cart is not found or empty");
		}
	}

}
