
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeSet;

@SuppressWarnings("unchecked")//Do not delete this line
public class UniqueWords
{
 public static void main (String[] args) {
  Scanner sc=new Scanner(System.in);
  List<String> array_list=new ArrayList<>();
  
  System.out.println("Enter Student's Article");
  String art1=sc.nextLine();
  String art=art1.toLowerCase();
  String arr[]=art.split("\\s|\\,|\\;|:|\\.|\\?|\\!|:\\s|\\,\\s");
  System.out.println("Number of words "+arr.length);
  for (int i = 0; i < arr.length; i++) 
            array_list.add(arr[i]);
  Set<String> set=new HashSet<>(array_list);
  System.out.println("Number of unique words "+set.size());
  System.out.println("The words are");
  TreeSet<String> tr = new TreeSet<String>(set);
   //tr.remove("");
   tr.remove(" ");
   int l=1;
   Iterator<String> itr=tr.iterator();
   while(((Iterator<String>) itr).hasNext()){
       System.out.println(l+". "+((Iterator<String>) itr).next());
       l++;
   }
}
}