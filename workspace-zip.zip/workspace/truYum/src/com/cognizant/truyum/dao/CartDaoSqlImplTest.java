package com.cognizant.truyum.dao;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.cognizant.truyum.model.MenuItem;

public class CartDaoSqlImplTest {

	public static void main(String[] args) throws CartEmptyException {
		// TODO Auto-generated method stub
        testAddCartItem();
        testAddCartItem();
        testAddCartItem();
        testGetAllCartItem();
        testRemoveCartItem();
        testGetAllCartItem();
	}
	public static void testAddCartItem(){
		Scanner sc=new Scanner(System.in);
		CartDao cd=new CartDaoSqlImpl();
		System.out.println("Enter the user id");
		Long ui=sc.nextLong();
		System.out.println("Enter the menu id");
		Long mid=sc.nextLong();
		cd.addCartItem(ui, mid);
	}
	public static void testGetAllCartItem(){
		Scanner sc=new Scanner(System.in);
		CartDao cd=new CartDaoSqlImpl();
    	List<MenuItem> mlp=new ArrayList<>();
    	System.out.println("Enter the id");
    	Long id=sc.nextLong();
    	mlp=cd.getAllCartItems(id);
    	for(MenuItem mit:mlp){
    		System.out.println(mit.toString());
    	}
	}
	public static void testRemoveCartItem() throws CartEmptyException{
		Scanner sc=new Scanner(System.in);
		CartDao cd=new CartDaoSqlImpl();
		System.out.println("Enter the user id");
		Long ui=sc.nextLong();
		System.out.println("Enter the menu id");
		Long mid=sc.nextLong();
		cd.removeCartItem(ui, mid);
	}
}
