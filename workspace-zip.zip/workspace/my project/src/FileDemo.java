import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import java.io.*;


import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class FileDemo {
public static String[] readFile(){
	FileReader fr=null;
	String[] ret=new String[50];
	int j=0;
	try {
		fr=new FileReader("log.txt");
		BufferedReader br=new BufferedReader(fr);
		do{
			if((ret[j++]=br.readLine())==null){
				break;
			}
		}while(true);
	} catch (FileNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	catch (IOException e){
		e.printStackTrace();
	}
	finally{
		try{
			fr.close();
		}
		catch (IOException e){
			e.printStackTrace();
		}
	}
	return ret;
}
public static void main(String[] args) {
	String ff[]=readFile();
	int count=0;
	String sp="";
	for(int i=0;i<ff.length;i++){
		sp=sp+ff[i]+" ";
	}
	sp=sp.toUpperCase();
	sp=" "+sp;
	String go[]=sp.split(" ");
	for(int i=1;i<go.length;i++){
		if(go[i].equals("KNOWLEDGE")){
			count++;
		}
	}
	System.out.println(count);
}
}

