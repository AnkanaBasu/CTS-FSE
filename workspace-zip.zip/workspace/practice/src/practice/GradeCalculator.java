package practice;

public class GradeCalculator extends Thread{
 private String studName;
 private char result;
 private int[] marks;
public String getStudName() {
	return studName;
}
public void setStudName(String studName) {
	this.studName = studName;
}
public char getResult() {
	return result;
}
public void setResult(char result) {
	this.result = result;
}
public int[] getMarks() {
	return marks;
}
public void setMarks(int[] marks) {
	this.marks = marks;
}
public GradeCalculator(String studName, int[] marks) {
	this.studName = studName;
	this.marks = marks;
}
 public void run(){
	 int total=0;
	 for(int i=0;i<this.marks.length;i++){
		 total=total+marks[i];
	 }
	 if(total<=500&&total>=400){
		 setResult('A');
	 }
	 else if(total<=399&&total>=300){
		 setResult('B');
	 }
	 else if(total<=299&&total>=200){
		 setResult('C');
	 }
	 else{
		 setResult('E');
	 }
	 System.out.println(getStudName()+":"+getResult());
 }
}
