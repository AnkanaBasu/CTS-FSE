package practice;

import java.util.ArrayList;
import java.util.List;

public class Order {

    private double discountPercentage;
	private List<FoodProduct> foodList=new ArrayList<>();
	
	public double getDiscountPercentage() {
		return discountPercentage;
	}

	public void setDiscountPercentage(double discountPercentage) {
		this.discountPercentage = discountPercentage;
	}

	public List<FoodProduct> getFoodList() {
		return foodList;
	}

	public void setFoodList(List<FoodProduct> foodList) {
		this.foodList = foodList;
	}
	
	//This method should set the discount percentage based on bank passed as argument 
	public void findDiscount(String bankName) {
     if(bankName.equals("HDFC")){
         discountPercentage=15.0;
     }
     else if(bankName.equals("ICICI")){
         discountPercentage=25.0;
     }
     else if(bankName.equals("CUB")){
         discountPercentage=30.0;
     }
     else if(bankName.equals("SBI")){
         discountPercentage=50.0;
     }
     else{
         discountPercentage=0.0;
     }
		// fill the code
		
	}
	
	//This method should add the FoodProduct Object into Food List
	public void addToCart(FoodProduct foodProductObject) {

		foodList.add(foodProductObject);
				
	}
			
	//method should return the total bill amount after discount 
	// based on the bank name
	public double calculateTotalBill() {
        double sum=0.0;
        for(FoodProduct f:foodList){
            sum=sum+(f.getCostPerUnit()*f.getQuantity());
        }
        double bill_amount=sum-(sum*(discountPercentage/100));
		// fill the code

		return bill_amount;
	}
			
			
}
