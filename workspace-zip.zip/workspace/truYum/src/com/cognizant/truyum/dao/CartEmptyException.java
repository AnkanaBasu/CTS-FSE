package com.cognizant.truyum.dao;

public class CartEmptyException extends Exception {

	public CartEmptyException(String msg) {
		System.out.println(msg);
		// TODO Auto-generated constructor stub
	}
	

}
