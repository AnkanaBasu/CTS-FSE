package com.cognizant.truyum.dao;

import java.sql.SQLException;
import java.util.List;

import com.cognizant.truyum.model.MenuItem;

public interface MenuItemDao {
public List<MenuItem> getMenuListAdmin();
public List<MenuItem> getMenuListCustomer();
public void modifyMenuItem(MenuItem menuItem);
public MenuItem getMenuItem(long menuItemId);

}
