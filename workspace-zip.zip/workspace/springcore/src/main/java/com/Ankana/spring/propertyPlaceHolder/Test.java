package com.Ankana.spring.propertyPlaceHolder;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {
public static void main(String[] args) {
	ApplicationContext ctx=new ClassPathXmlApplicationContext("com/Ankana/spring/propertyPlaceHolder/config.xml");
    myDAO dao=(myDAO) ctx.getBean("mydao");
    System.out.println(dao);
}
}
