import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        Scanner sc=new Scanner(System.in);
        Flight fl=new Flight(548,"NGP","KLK",8,7500);
        FlightManagementSystem fms=new FlightManagementSystem();
        if(fms.addFlight(fl)){
        	System.out.println("Flight details added successfully");
        }
        else{
        	System.out.println("Addition not done");
        }
	}

}
