package lamdaDemo;

public class tryLamda {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Math math=(a,b)->a+b;
       System.out.println(math.operation(6, 5));
	}

}
