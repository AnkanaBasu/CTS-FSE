package com.Ankana.spring.InnerBeans;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {
public static void main(String[] args) {
	ApplicationContext ctx=new ClassPathXmlApplicationContext("com/Ankana/spring/InnerBeans/configure.xml");
	Employee emp=(Employee) ctx.getBean("employee");
	System.out.println(emp);
	System.out.println(emp.hashCode());
	Employee emp1=(Employee) ctx.getBean("employee");
	System.out.println(emp1);
	System.out.println(emp1.hashCode());
}
}
