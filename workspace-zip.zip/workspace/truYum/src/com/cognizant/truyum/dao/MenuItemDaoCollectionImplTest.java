package com.cognizant.truyum.dao;

import java.text.ParseException;
import java.util.List;
import java.util.Scanner;

import com.cognizant.truyum.model.MenuItem;
import com.cognizant.truyum.util.DateUtil;

public class MenuItemDaoCollectionImplTest {
public static void main(String[] args) throws ParseException {
	MenuItemDaoCollectionImplTest.testGetMenuItemListAdmin();
	testMenuItemListCustomer();
	testModifyMenuItem();
	testGetMenuItemListAdmin();
	testGetMenuItem();
}
public static void testGetMenuItemListAdmin() throws ParseException{
	MenuItemDao mid=new MenuItemDaoCollectionImpl();
	List<MenuItem> lm=mid.getMenuListAdmin();
	System.out.println("ADMIN LIST");
	for(MenuItem m:lm){
		System.out.println(m.toString());
	}
}
public static void testMenuItemListCustomer() throws ParseException{
	MenuItemDao mid=new MenuItemDaoCollectionImpl();
	List<MenuItem> lm=mid.getMenuListCustomer();
	System.out.println("CUSTOMER LIST");
	for(MenuItem m:lm){
		System.out.println(m.toString());
	}
}
public static void testModifyMenuItem() throws ParseException{
	MenuItemDao mid=new MenuItemDaoCollectionImpl();
	MenuItem m=new MenuItem(3, "Pizza", 139.0f, false, DateUtil.convertToDate("21/08/2018"), "Main Course", true);
	mid.modifyMenuItem(m);
	System.out.println("Item is modified");
}
public static void testGetMenuItem() throws ParseException {
	Scanner sc=new Scanner(System.in);
	MenuItemDao mid=new MenuItemDaoCollectionImpl();
	System.out.println("Enter the id of the item:");
	long i=sc.nextLong();
	MenuItem result=mid.getMenuItem(i);
	System.out.println("YOUR ITEM IS:");
	System.out.println(result.toString());
}
}
