package practice;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

public class gg {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
	       int n=sc.nextInt();
	       String emp[]=new String[n];
	       String sDate1="01/01/2019";
	       try {
			Date date1=new SimpleDateFormat("dd/MM/yyyy").parse(sDate1);
			int j=0;
			for(int i=0;i<n;i++){
			String id=sc.nextLine();
			String ss=sc.nextLine();
			Date date2=new SimpleDateFormat("dd/MM/yyyy").parse(ss);
			long diff=date1.getTime()-date2.getTime();
			long year=diff/(1000l*60*60*24*365);
			if(year>=5){
				emp[j++]=id;
			}
			}
			System.out.println(emp);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}  
	}

}
