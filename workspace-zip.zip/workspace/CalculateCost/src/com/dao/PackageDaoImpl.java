package com.dao;

import java.util.List;

public class PackageDaoImpl implements PackageDao{

	@Override
	public List<Package> getAllPackage() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public double calculatePackageCost(Package p) {

		return 0;
	}

	@Override
	public void insertIntoTable(Package p) {
		// TODO Auto-generated method stub
		
	}

}
