package com.Ankana.spring.reftype;

public class StudentResult {
	private int roll;
	private String name;
	private Scores score;

	public int getRoll() {
		return roll;
	}

	public void setRoll(int roll) {
		this.roll = roll;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Scores getScore() {
		return score;
	}

	public void setScore(Scores score) {
		this.score = score;
	}

	@Override
	public String toString() {
		return "StudentResult [roll=" + roll + ", name=" + name + ", score=" + score + "]";
	}

}
