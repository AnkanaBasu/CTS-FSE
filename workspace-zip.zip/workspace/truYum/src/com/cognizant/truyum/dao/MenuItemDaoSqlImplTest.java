package com.cognizant.truyum.dao;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.cognizant.truyum.model.MenuItem;
import com.cognizant.truyum.util.DateUtil;

public class MenuItemDaoSqlImplTest {

	public static void main(String[] args) throws ParseException {
		// TODO Auto-generated method stub
        testGetMenuItemListAdmin();
        testGetMenuItemListCustomer();
        testGetMenuItem();
        testModifyMenuItem();
        testGetMenuItemListAdmin();
	}
    public static void testGetMenuItemListAdmin() throws ParseException{
    	MenuItemDao mi=new MenuItemDaoSqlImpl();
    	List<MenuItem> mlp=new ArrayList<>();
    	mlp=mi.getMenuListAdmin();
    	for(MenuItem mit:mlp){
    		System.out.println(mit.toString());
    	}
    }
    public static void testGetMenuItemListCustomer(){
    	MenuItemDao mi=new MenuItemDaoSqlImpl();
    	List<MenuItem> mlp=new ArrayList<>();
    	mlp=mi.getMenuListCustomer();
    	for(MenuItem mit:mlp){
    		System.out.println("CUSTOMER");
    		System.out.println(mit.toString());
    	}
    }
    public static void testModifyMenuItem() throws ParseException{
    	MenuItemDao mi=new MenuItemDaoSqlImpl();
    	MenuItem item=new MenuItem(2,"Burger",140.0f, true, DateUtil.convertToDate("23/12/2017"), "Snacks", false);
    	mi.modifyMenuItem(item);
    	/*System.out.println("After modification:");
    	System.out.println();*/
    }
    public static void testGetMenuItem(){
    Scanner sc=new Scanner(System.in);
    MenuItemDao mi=new MenuItemDaoSqlImpl();
    System.out.println("Enter the id of the item");
    long menuItemId=sc.nextLong();
    MenuItem mn=mi.getMenuItem(menuItemId);
    System.out.println(mn.toString());
    }
}
