package com.cognizant.truyum.dao;

import java.util.ArrayList;
import java.util.List;

import com.cognizant.truyum.model.MenuItem;

public class CartDaoCollectionImplTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        testAddCartItem();
        testGetAllCartItem();
        testRemoveCartItem();
        testGetAllCartItem();
	}
    public static void testAddCartItem(){
    	CartDaoCollectionImpl c=new CartDaoCollectionImpl();
    	c.addCartItem(121, 1);
    	c.addCartItem(121, 2);
    	c.addCartItem(1, 1);
    }
    public static void testGetAllCartItem(){
    	List<MenuItem> mil=new ArrayList<MenuItem>();
    	CartDaoCollectionImpl c=new CartDaoCollectionImpl();
    		mil=c.getAllCartItems(121);
    		for(MenuItem m:mil){
    			System.out.println(m);
    		}
    	
    }
    public static void testRemoveCartItem(){
    CartDaoCollectionImpl c=new CartDaoCollectionImpl();
    c.removeCartItem(121, 1);
    }
}
