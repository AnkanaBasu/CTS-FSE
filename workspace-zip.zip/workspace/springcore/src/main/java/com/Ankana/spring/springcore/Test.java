package com.Ankana.spring.springcore;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {

	public static void main(String[] args) {
		ApplicationContext ctx=new ClassPathXmlApplicationContext("config.xml");
		Employee empl=(Employee) ctx.getBean("emp");
		System.out.println("Employee Id: "+empl.getId()) ;
        System.out.println("Employee name: "+empl.getName());
        System.out.println("Projects are: "+empl.getProjects());
        //System.out.println("Projects are: "+empl.getProjects().getClass());
        System.out.println("Ratings are: "+empl.getRatings());
        //System.out.println(empl.getRatings().getClass());
        System.out.println(empl);
        System.out.println(empl.getPerfomances());
	}

}
