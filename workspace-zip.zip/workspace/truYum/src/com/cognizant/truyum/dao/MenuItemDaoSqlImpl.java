package com.cognizant.truyum.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.cognizant.truyum.model.MenuItem;

public class MenuItemDaoSqlImpl implements MenuItemDao {

	@Override
	public List<MenuItem> getMenuListAdmin() {
		// TODO Auto-generated method stub
		List<MenuItem> men=new ArrayList<>();
		try{	
		Connection con=ConnectionHandler.getConnection();
		String qr="select * from menuitem";
		PreparedStatement ps=con.prepareStatement(qr);
		ResultSet rs=ps.executeQuery();
		while(rs.next()){
			long id=rs.getLong(1);
			String nm=rs.getString(2);
			float price=rs.getFloat(3);
			boolean act=rs.getBoolean(4);
			Date d=rs.getDate(5);
			String cat=rs.getString(6);
			boolean fr=rs.getBoolean(7);
			MenuItem gg=new MenuItem(id,nm,price,act,d,cat,fr);
			men.add(gg);
		}
		}
		catch(ClassNotFoundException|SQLException e){
			System.out.println("Exception occured");
		}
		return men;
	}

	@Override
	public List<MenuItem> getMenuListCustomer() {
		List<MenuItem> men=new ArrayList<>();
		try{	
		Connection con=ConnectionHandler.getConnection();
		String qr="select * from menuitem where active=1 and dateOfLaunch<CURDATE()";
		PreparedStatement ps=con.prepareStatement(qr);
		ResultSet rs=ps.executeQuery();
		while(rs.next()){
			long id=rs.getLong(1);
			String nm=rs.getString(2);
			float price=rs.getFloat(3);
			boolean act=rs.getBoolean(4);
			Date d=rs.getDate(5);
			String cat=rs.getString(6);
			boolean fr=rs.getBoolean(7);
			MenuItem gg=new MenuItem(id,nm,price,act,d,cat,fr);
			men.add(gg);
		}
		}
		catch(ClassNotFoundException|SQLException e){
			System.out.println("Exception Occured");
		}
		return men;
	}

	@Override
	public void modifyMenuItem(MenuItem menuItem) {
		try{
			Connection con=ConnectionHandler.getConnection(); 
			String qr="Update menuitem set name=?,price=?,active=?,dateOfLaunch=?,category=?,freeDelivery=? where id=?";
			PreparedStatement ps=con.prepareStatement(qr);
			ps.setString(1,menuItem.getName());
			ps.setFloat(2, menuItem.getPrice());
			ps.setBoolean(3, menuItem.isActive());
			ps.setDate(4, new java.sql.Date(menuItem.getDateOfLaunch().getTime()));
			ps.setString(5,menuItem.getCategory());
			ps.setBoolean(6, menuItem.isFreeDelivery());
			ps.setLong(7, menuItem.getId());
			int i=ps.executeUpdate();
			System.out.println(i+" rows updated");
			
		}
		catch(ClassNotFoundException|SQLException e){
			System.out.println("Exception Occured");
		}
		
	}

	@Override
	public MenuItem getMenuItem(long menuItemId) {
		MenuItem item=null;
		try{	
			Connection con=ConnectionHandler.getConnection();
			String qr="select * from menuitem where id=?";
			PreparedStatement ps=con.prepareStatement(qr);
			ps.setLong(1, menuItemId);
			ResultSet rs=ps.executeQuery();
			while(rs.next()){
				long id=rs.getLong(1);
				String nm=rs.getString(2);
				float price=rs.getFloat(3);
				boolean act=rs.getBoolean(4);
				Date d=rs.getDate(5);
				String cat=rs.getString(6);
				boolean fr=rs.getBoolean(7);
				item=new MenuItem(id,nm,price,act,d,cat,fr);
			}
			}
			catch(ClassNotFoundException|SQLException e){
				System.out.println("Exception Occured");
			}
		
		return item;
	}

}
