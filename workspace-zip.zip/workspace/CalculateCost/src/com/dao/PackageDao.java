package com.dao;

import java.util.List;

public interface PackageDao {
public List<Package> getAllPackage();
public double calculatePackageCost(Package p);
public void insertIntoTable(Package p);
}
