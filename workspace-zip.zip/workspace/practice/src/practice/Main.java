package practice;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
       Scanner sc=new Scanner(System.in);
       try{
       System.out.println("Enter the number of employees");
       int n=sc.nextInt();
       sc.nextLine();
       List<String> emp=new ArrayList<String>();
       String sDate1="01/01/2019";
		Date date1=new SimpleDateFormat("dd/MM/yyyy").parse(sDate1);
		int j=0;
		for(int i=0;i<n;i++){
		    System.out.println("Enter id");
		    String id=sc.nextLine();
		    System.out.println("Enter Date");
		    String ss=sc.nextLine();
		    Date date2=new SimpleDateFormat("dd/MM/yyyy").parse(ss);
		    long diff=date1.getTime()-date2.getTime();
		    long year=diff/(1000l*60*60*24*365);
		    if(year>=5){
			  emp.add(id);
		     }
		  }
		Collections.sort(emp);
		for(String s:emp)
		System.out.println(s);
	} catch (ParseException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}  
       

	}

}
