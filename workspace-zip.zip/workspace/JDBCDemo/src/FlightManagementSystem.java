import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;


public class FlightManagementSystem {
 public boolean addFlight(Flight flightObj){
	 boolean ret=false;
	 try {
		Connection con=DB.getConnection();
		String qry="insert into flight values(?,?,?,?,?)";
		PreparedStatement ps=con.prepareStatement(qry);
		ps.setInt(1, flightObj.getFlightId());
		ps.setString(2, flightObj.getSource());
		ps.setString(3, flightObj.getDestination());
		ps.setInt(4, flightObj.getNoOfSeats());
		ps.setDouble(5, flightObj.getFlightFare());
		int up=ps.executeUpdate();
		if(up>0){
			ret=true;
		}
	} catch (ClassNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	 return ret;
 }
}
