package com.cognizant.truyum.dao;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.cognizant.truyum.model.Cart;
import com.cognizant.truyum.model.MenuItem;

public class CartDaoCollectionImpl implements CartDao {
	
	
	private static HashMap<Long, Cart> userCarts=null;
	public CartDaoCollectionImpl() {
		try{
			if(CartDaoCollectionImpl.userCarts==null){
				CartDaoCollectionImpl.userCarts=new HashMap<>();
			}
		}
		catch (Exception e) {
			// TODO: handle exception
		}
	}

	


	public void addCartItem(long userId, long menuItemId) {
		Cart cart=CartDaoCollectionImpl.userCarts.getOrDefault(userId, new Cart(new ArrayList<MenuItem>(), 0));
		List<MenuItem> items=cart.getMenuItemList();
		MenuItemDaoCollectionImpl m = null;
		@SuppressWarnings("static-access")
		
		List<MenuItem> menuitems=m.getMenuItemList();
		for(MenuItem i:menuitems){
			if(i.getId()==menuItemId){
				items.add(i);
				cart.setMenuItemList(items);
				cart.setTotal(cart.getTotal()+i.getPrice());
				CartDaoCollectionImpl.userCarts.put(userId, cart);
		try {
			m = new MenuItemDaoCollectionImpl();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
			}
		}

	}

	@Override
	public List<MenuItem> getAllCartItems(final long UserId){
		// TODO Auto-generated method stub
		return CartDaoCollectionImpl.userCarts.get(UserId).getMenuItemList();
	}

	@Override
	public void removeCartItem(long userId, long menuItemId) throws CartEmptyException {
		Cart c=CartDaoCollectionImpl.userCarts.get(userId);
		List<MenuItem> items=c.getMenuItemList();
		if(items==null){
			throw new CartEmptyException("Cart is Empty");
		}
		MenuItem obj=null;
		for(MenuItem item:items){
			if(item.getId()==menuItemId){
				obj=item;
			}
		}
		if(obj!=null){
			items.remove(obj);
			c.setMenuItemList(items);
			c.setTotal(c.getTotal()-obj.getPrice());
		}
        CartDaoCollectionImpl.userCarts.put(userId, c);
	}
}
