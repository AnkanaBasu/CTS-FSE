import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class Main {
public static void main(String[] args) throws ClassNotFoundException, IOException {
	Scanner sc=new Scanner(System.in);
	EmployeeUtility eu=new EmployeeUtility();
	String filename="employeeList.ser";
	ArrayList<Employee> el=new ArrayList<>();
    el.add(new Employee(123, "Ankana", 4.5f));
    el.add(new Employee(122, "Ankeeta", 4.2f));
    el.add(new Employee(126, "Angika", 3.5f));
    boolean d=eu.addEmployee(filename, el);
    if(d==true){
    	System.out.println("Successful");
    }
    else{
    	System.out.println("Not Done");
    }
    System.out.println("Enter the id you want");
    int employeeId=sc.nextInt();
    Employee e=eu.viewEmployeeById(filename, employeeId);
    System.out.println(e.getEmployeeId()+" "+e.getName()+" "+e.getAppraisalRating());
}
}
