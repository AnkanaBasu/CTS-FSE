
import java.io.*;
import java.util.ArrayList;
public class EmployeeUtility {
    public boolean addEmployee(String fileName,ArrayList<Employee> employeeList){
        boolean ret=false;
    	FileOutputStream fos;
        ObjectOutputStream oos;
        try {
			fos=new FileOutputStream(fileName);
			 oos=new ObjectOutputStream(fos);
		        for(Employee e:employeeList){
		            oos.writeObject(e);
		        }
		        ret=true;
		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
       return ret;
        
    }
    @SuppressWarnings("unchecked")
	public Employee viewEmployeeById(String fileName,int employeeId) throws IOException, ClassNotFoundException{
    	ArrayList<Employee> emp=new ArrayList<>();
    	FileInputStream fis=new FileInputStream(fileName);
    	@SuppressWarnings("resource")
		ObjectInputStream ois=new ObjectInputStream(fis);
    	emp=(ArrayList<Employee>)ois.readObject();
    	for(Employee e:emp){
    		if(e.getEmployeeId()==employeeId){
    			return e;
    		}
    	}
    	return null;
    }
    
}