package com.Ankana.spring.springcore;

import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

public class Employee {
	private int id;
	private String name;
	private List<String> projects;
	private Set<Double> ratings;
	private Map<Integer,String> projectName;
	private Properties perfomances;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<String> getProjects() {
		return projects;
	}

	public void setProjects(List<String> projects) {
		this.projects = projects;
	}

	public Set<Double> getRatings() {
		return ratings;
	}

	public void setRatings(Set<Double> ratings) {
		this.ratings = ratings;
	}

	public Map<Integer,String> getProjectName() {
		return projectName;
	}

	public void setProjectName(Map<Integer,String> projectName) {
		this.projectName = projectName;
	}

	public Properties getPerfomances() {
		return perfomances;
	}

	public void setPerfomances(Properties perfomances) {
		this.perfomances = perfomances;
	}

	@Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + ", projects=" + projects + ", ratings=" + ratings
				+ ", projectName=" + projectName + ", perfomances=" + perfomances + "]";
	}

	

	



}
