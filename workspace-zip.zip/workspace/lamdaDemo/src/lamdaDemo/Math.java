package lamdaDemo;

public interface Math {
   public int operation(int a,int b); 
}
