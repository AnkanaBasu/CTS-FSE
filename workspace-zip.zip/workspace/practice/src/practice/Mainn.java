package practice;

import java.util.*;

public class Mainn {

 public static void main(String[] args) {

      //fill the code
   Scanner sc = new Scanner(System.in);
   System.out.println("Enter the number of Threads:");
   int t = sc.nextInt();
   sc.nextLine();
   int i=0;
   GradeCalculator[] gc=new GradeCalculator[t];
   while(i<t){
     System.out.println("Enter the String:");
     String[] st=sc.nextLine().split(":");
     int[] arr={Integer.parseInt(st[1]),Integer.parseInt(st[2]),Integer.parseInt(st[3]),Integer.parseInt(st[4]),Integer.parseInt(st[5])};
     gc[i] = new GradeCalculator(st[0],arr);
     i++;
   }
   for(;i>0;i--)
     gc[t-i].run();
 }
}