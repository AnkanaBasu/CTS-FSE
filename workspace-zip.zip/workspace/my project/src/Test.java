import java.util.Set;

public class Test {

	public static void main(String[] args) {
		
		Set set=new treeSet();
set.add("2");
set.add(3);
set.add("1");

	}
	
}
