import java.util.*;

public class ArrayListDemo {

		// TODO Auto-generated method stub
		List list=new ArrayList();
		ArrayList list1=new ArrayList();
		List<String> list2=new ArrayList<String>();
		List<String> list3=new ArrayList<>();
		ArrayList<AddressBook> ab=new ArrayList<>();
		public ArrayList<AddressBook> getAb() {
			return ab;
		}
		public void setAb(ArrayList<AddressBook> ab) {
			this.ab = ab;
			ab.add(new AddressBook());
		}
		public boolean isEmpty(){
	        return ab.isEmpty();
	    }
	    
}
